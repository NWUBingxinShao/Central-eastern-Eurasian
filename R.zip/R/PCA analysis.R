# Load required libraries
library(dplyr)
library(ggplot2)

# Read barley dataset
barley_data <- read.csv("path/to/barley.csv")
wheat_data <- read.csv("path/to/wheat.csv")

# Add a label to each dataset to distinguish between them
wheat_data$type <- "wheat"
barley_data$type <- "barley"

# Combine the two datasets into one
merged_data <- rbind(wheat_data, barley_data)

# Create a unique ID for each site based on coordinates and date
merged_data$id <- paste(merged_data$Latitude, merged_data$Longitude, merged_data$DateMedian, sep = "_")

# Count occurrences of each unique ID
id_counts <- table(merged_data$id)

# Display the counts of unique IDs
View(id_counts)

# Identify IDs that occur more than once
repeated_ids <- names(id_counts[id_counts >= 2])

# Assign site types based on the occurrence of IDs
merged_data$site_type <- ifelse(merged_data$id %in% repeated_ids, 
                                "both", 
                                ifelse(merged_data$type == "barley", 
                                       "only_barley", 
                                       "only_wheat"))


# Create a unique ID using coordinates and date
barley_data$id <- paste(barley_data$Latitude, barley_data$Longitude, barley_data$DateMedian, sep = "_")

# Select features for analysis
selected_features <- c("Latitude", "Longitude", "elevation", "NEAR_DIST", "DateMedian", "NEAR_Level",
                       "Main_re", "bi8", "bi7", "bi15", "bi16", "bi17", "bi6", "bi14", 
                       "bi5", "bi13", "bi4", "bi12", "id", "bi3", "bi11", "bi2", 
                       "bi10", "bi19", "bi1", "bi18", "bi9")

# Extract selected features
data_for_analysis <- barley_data[, selected_features]

# Split data by region ('Main_re')
split_data_region <- split(data_for_analysis, data_for_analysis$Main_re)

# Ensure that the Main_re variable is a factor
wheat_data$Main_re <- as.factor(wheat_data$Main_re)

# Define predictor variables
predictors <- wheat_data[, c("environmental variables")]

# Perform Principal Component Analysis (PCA)
pca_model_wheat <- prcomp(predictors, center = TRUE, scale. = TRUE)

# Summary of PCA results
summary(pca_model_wheat)

# Extract PCA results for plotting
pca_results <- pca_model_wheat$x[, 1:ncol(pca_model_wheat$x)]

# Prepare data for plotting
pca_data <- data.frame(PC1 = pca_results[,1], PC2 = pca_results[,2], Main_re = wheat_data$Main_re)
pca_data <- data.frame(PC1 = pca_results[,1], PC2 = pca_results[,2], Main_re = barley_data$Main_re)
# pca_data <- data.frame(PC1 = pca_results[,1], PC2 = pca_results[,2], site_type = combined_data$site_type)

# Load necessary libraries
library(ggplot2)
library(factoextra)
library(corrplot)

# Calculate the proportion of variance for PC1 and PC2
pc1_var <- round(summary(pca_model_wheat)$importance[2, 1] * 100, 2)
pc2_var <- round(summary(pca_model_wheat)$importance[2, 2] * 100, 2)

# Labels for plot axes
xlab <- paste0("PC1 (", pc1_var, "%)")
ylab <- paste0("PC2 (", pc2_var, "%)")

# Define ggplot2 theme settings
my_theme <- theme_set(theme_minimal()) + 
  theme(
    axis.title  = element_text(size = 15),
    axis.text   = element_text(size = 12),
    legend.text = element_text(size = 14)
  )

# Scatter plot with confidence ellipses
p1 <- ggplot(pca_data, aes(x = PC1, y = PC2, color = Main_re)) +
  stat_ellipse(aes(fill = Main_re), level = 0.95, geom = "polygon", alpha = 0.2, color = NA) +
  geom_point(size = 8) +
  labs(x = xlab, y = ylab, color = "") +
  guides(fill = FALSE) +
  my_theme

# Display the scatter plot
print(p1)

# PCA variable analysis
var <- get_pca_var(pca_model_wheat)

# Plot variable distribution in PCA space
fviz_pca_var(pca_model_wheat, col.var = "black")

# Plot squared cosines (cos2) for variables
fviz_cos2(pca_model_wheat, choice = "var", axes = 1:2)

# Adjust font sizes for cos2 plot
fviz_cos2(pca_model_wheat, choice = "var", axes = 1:2) +
  theme(
    axis.text = element_text(size = 14),
    axis.title = element_text(size = 16),
    strip.text = element_text(size = 14),
    plot.title = element_text(size = 18)
  )

# Color variables by cos2 values
fviz_pca_var(pca_model_wheat, col.var = "cos2",
             gradient.cols = c("#00AFBB", "#E7B800", "#FC4E07"), 
             repel = TRUE)

# Plot variable contributions to PC1
fviz_contrib(pca_model_wheat, choice = "var", axes = 1, top = 10) +
  theme(
    axis.text = element_text(size = 14),
    axis.title = element_text(size = 16),
    strip.text = element_text(size = 14),
    plot.title = element_text(size = 18)
  )

# Plot variable contributions to PC2
fviz_contrib(pca_model_wheat, choice = "var", axes = 2, top = 10) +
  theme(
    axis.text = element_text(size = 14),
    axis.title = element_text(size = 16),
    strip.text = element_text(size = 14),
    plot.title = element_text(size = 18)
  )

# Biplot of PCA results
fviz_pca_biplot(pca_model_wheat, 
                col.ind = wheat_data$Main_re, palette = "jco", 
                addEllipses = TRUE, label = "var",
                col.var = "black", repel = TRUE,
                legend.title = "Main_re")
