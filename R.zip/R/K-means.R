# K-means example：Barley data 

# Import necessary libraries
library(ggplot2)
library(cluster)
library(fpc)

# Load the barley and wheat datasets (replace with actual data paths)
barley_data <- read.csv("path/to/barley_data.csv")
wheat_data <- read.csv("path/to/wheat_data.csv")

# Select features for clustering
selected_features_barley <- c("Latitude", "Longitude", "elevation", 'NEAR_DIST', 'DateMedian', 'NEAR_Level',
                              "bi8", "bi7", "bi15", "bi16", "bi17",
                              "bi6", "bi14", "bi5", "bi13", "bi4", "bi12", 
                              "bi3", "bi11", "bi2", "bi10", "bi19", "bi1", "bi18", "bi9")

# Extract and standardize the selected features
data_for_clustering_barley <- scale(barley_data[, selected_features_barley])

# Calculate the correlation matrix and remove highly correlated variables
cor_threshold <- 0.75
correlation_matrix_barley <- cor(data_for_clustering_barley[, -c(1, 2)])  # Exclude Latitude and Longitude

# Identify and remove highly correlated features
for (i in 1:(ncol(correlation_matrix_barley) - 1)) {
  for (j in (i + 1):ncol(correlation_matrix_barley)) {
    if (abs(correlation_matrix_barley[i, j]) > cor_threshold) {
      selected_features_barley <- selected_features_barley[selected_features_barley != names(data_for_clustering_barley)[j + 2]] # Adjust index to match original data columns
    }
  }
}

# Update the data with selected features and re-standardize
data_for_clustering_barley <- scale(barley_data[, c("Latitude", "Longitude", selected_features_barley)])

# Function to calculate the Calinski-Harabasz (CH) index
calculate_ch_index <- function(data, k) {
  kmeans_model <- kmeans(data, centers = k)
  cluster_stats <- cluster.stats(dist(data), kmeans_model$cluster)
  return(cluster_stats$ch)
}

# Determine the optimal number of clusters (K) using CH index
set.seed(12)
k_values <- 2:10
ch_indices <- sapply(k_values, calculate_ch_index, data = data_for_clustering_barley)
best_k <- k_values[which.max(ch_indices)]

# Perform K-means clustering with the optimal K
kmeans_model_barley <- kmeans(data_for_clustering_barley, centers = best_k, nstart = 500)

# Add clustering results to the dataset
clustered_data_barley <- barley_data[, c("Latitude", "Longitude")]
clustered_data_barley$cluster <- as.factor(kmeans_model_barley$cluster)

# Define color palette
color_palette <- c("#9400D3", "#27A47C", "#00FFFF", "#3983B1", "#FFA500")

# Plot clustering results for barley data
ggplot(clustered_data_barley, aes(x = Longitude, y = Latitude, color = cluster)) +
  geom_point(size = 2.5) +
  scale_color_manual(values = color_palette) +
  labs(title = "K-means Clustering of Barley Data",
       x = "Longitude", y = "Latitude",
       color = "Cluster") +
  theme_minimal()
