analyze_wheat_data <- function(file_path) {
  # Load necessary packages
  if (!requireNamespace("UpSetR", quietly = TRUE)) {
    install.packages("UpSetR")
  }
  if (!requireNamespace("ggplot2", quietly = TRUE)) {
    install.packages("ggplot2")
  }
  if (!requireNamespace("cowplot", quietly = TRUE)) {
    install.packages("cowplot")
  }
  library(UpSetR)
  library(ggplot2)
  library(cowplot)
  library(reshape2)
  
  # Read CSV file
  data <- read.csv(file_path)
  
  # Function to extract and sort columns based on a pattern
  extract_and_sort_columns <- function(data, pattern) {
    cols <- data[, grep(pattern, names(data))]
    col_names <- names(cols)
    sorted_col_names <- col_names[order(as.numeric(gsub("[^0-9]", "", col_names)))]
    sorted_cols <- cols[, sorted_col_names]
    return(sorted_cols)
  }
  
  # Extract and sort columns based on different patterns
  contribution_cols <- extract_and_sort_columns(data, "\\.contribution$")
  permutation_importance_cols <- extract_and_sort_columns(data, "\\.permutation.importance$")
  training_gain_cols <- extract_and_sort_columns(data, "^Training\\.gain\\.with\\.only\\.")
  test_gain_cols <- extract_and_sort_columns(data, "^Test\\.gain\\.with\\.only\\.")
  auc_cols <- extract_and_sort_columns(data, "^AUC\\.with\\.only\\.")
  
  # Function to add a source column to the last row of data
  add_source_column <- function(cols, source) {
    last_row <- cols[nrow(cols), , drop = FALSE]
    last_row$Source <- source
    return(last_row)
  }
  
  # Add source column to the last row of each dataset
  last_row_contribution <- add_source_column(contribution_cols, "Contribution")
  last_row_permutation_importance <- add_source_column(permutation_importance_cols, "Permutation Importance")
  last_row_training_gain <- add_source_column(training_gain_cols, "Training Gain")
  last_row_test_gain <- add_source_column(test_gain_cols, "Test Gain")
  last_row_auc <- add_source_column(auc_cols, "AUC")
  
  # Function to extract and format column names
  extract_bix <- function(col_names) {
    bix <- gsub("[^0-9]", "", col_names)
    bix <- paste0("bi", bix)
    return(bix)
  }
  
  # Update column names to include "bi" prefix and correct the source column name
  colnames(last_row_contribution) <- extract_bix(colnames(last_row_contribution))
  colnames(last_row_permutation_importance) <- extract_bix(colnames(last_row_permutation_importance))
  colnames(last_row_training_gain) <- extract_bix(colnames(last_row_training_gain))
  colnames(last_row_test_gain) <- extract_bix(colnames(last_row_test_gain))
  colnames(last_row_auc) <- extract_bix(colnames(last_row_auc))
  
  colnames(last_row_contribution)[ncol(last_row_contribution)] <- "Source"
  colnames(last_row_permutation_importance)[ncol(last_row_permutation_importance)] <- "Source"
  colnames(last_row_training_gain)[ncol(last_row_training_gain)] <- "Source"
  colnames(last_row_test_gain)[ncol(last_row_test_gain)] <- "Source"
  colnames(last_row_auc)[ncol(last_row_auc)] <- "Source"
  
  # Combine all datasets into one dataframe
  final_data <- rbind(last_row_contribution,
                      last_row_permutation_importance,
                      last_row_training_gain,
                      last_row_test_gain,
                      last_row_auc)
  
  # Function to find the top 8 bi factors
  find_top_bi_factors <- function(data) {
    data <- data[, !names(data) %in% "Source"]
    data_vec <- unlist(data)
    top_bi_indexes <- order(data_vec, decreasing = TRUE)[1:8]
    top_bi_factors <- data_vec[top_bi_indexes]
    return(top_bi_factors)
  }
  
  # Extract top 8 bi factors for each indicator
  top_bi_factors_contribution <- find_top_bi_factors(last_row_contribution)
  top_bi_factors_permutation_importance <- find_top_bi_factors(last_row_permutation_importance)
  top_bi_factors_training_gain <- find_top_bi_factors(last_row_training_gain)
  top_bi_factors_test_gain <- find_top_bi_factors(last_row_test_gain)
  top_bi_factors_auc <- find_top_bi_factors(last_row_auc)
  
  # Standardize bi factor values
  standardize <- function(x) {
    return((x - mean(x)) / sd(x))
  }
  
  std_contribution <- standardize(top_bi_factors_contribution)
  std_permutation_importance <- standardize(top_bi_factors_permutation_importance)
  std_training_gain <- standardize(top_bi_factors_training_gain)
  std_test_gain <- standardize(top_bi_factors_test_gain)
  std_auc <- standardize(top_bi_factors_auc)
  
  # Ensure all indicators have the same number of bi factors
  max_length <- max(length(std_contribution), length(std_permutation_importance), length(std_training_gain), length(std_test_gain), length(std_auc))
  
  std_contribution <- head(std_contribution, max_length)
  std_permutation_importance <- head(std_permutation_importance, max_length)
  std_training_gain <- head(std_training_gain, max_length)
  std_test_gain <- head(std_test_gain, max_length)
  std_auc <- head(std_auc, max_length)
  
  # Adjust standardized values to be non-negative
  min_val <- min(c(std_contribution, std_permutation_importance, std_training_gain, std_test_gain, std_auc), na.rm = TRUE)
  if (min_val < 0) {
    std_contribution <- pmax(std_contribution, 0) + abs(min_val)
    std_permutation_importance <- pmax(std_permutation_importance, 0) + abs(min_val)
    std_training_gain <- pmax(std_training_gain, 0) + abs(min_val)
    std_test_gain <- pmax(std_test_gain, 0) + abs(min_val)
    std_auc <- pmax(std_auc, 0) + abs(min_val)
  }
  
  # Create a dataframe for standardized values
  all_std_factors_df <- data.frame(
    BiFactor = rep(names(std_contribution), 5),
    Value = c(std_contribution, std_permutation_importance, std_training_gain, std_test_gain, std_auc),
    Indicator = rep(c("Contribution", "Permutation Importance", "Training Gain", "Test Gain", "AUC"), each = max_length)
  )
  
  # Aggregate and find the top 5 bi factors
  aggregated_factors <- aggregate(Value ~ BiFactor, data = all_std_factors_df, sum)
  top_five_factors <- aggregated_factors[order(-aggregated_factors$Value), ][1:5, ]
  print(top_five_factors)
  
  # Visualize standardized values with grouped bar plot
  group_bar_plot <- ggplot(all_std_factors_df, aes(x = BiFactor, y = Value, fill = Indicator)) +
    geom_bar(stat = "identity", position = "dodge") +
    scale_fill_manual(values = c("#E89DA0", "#88CEE6", "#F6C8A8", "#B2D3A4", "#B696B6")) +
    theme_minimal() +
    labs(title = paste(file_title, "Standardized Values of BiFactors Across Indicators"),
         x = "Bi-Factors",
         y = "Standardized Value") +
    theme(axis.text.x = element_text(angle = 45, hjust = 1))
  
  # Visualize top 5 bi factors with a bar plot
  sd_bar_plot <- ggplot(top_five_factors, aes(x = reorder(BiFactor, -Value), y = Value)) +
    geom_bar(stat = "identity", fill = "#F58383", color = "black") +
    geom_text(aes(label = round(Value, 2)), vjust = -0.5, color = "black", size = 3.5) +
    theme_minimal() +
    labs(title = paste(file_title, "Top 5 BiFactors by Aggregated Standardized Values"),
         x = "Bi-Factor",
         y = "Aggregated Standardized Value") +
    theme(axis.text.x = element_text(angle = 45, hjust = 1))
  
  # Create heatmap data and plot
  heatmap_data <- dcast(all_std_factors_df, BiFactor ~ Indicator, value.var = "Value")
  heatmap_data_top5 <- heatmap_data[heatmap_data$BiFactor %in% top_five_factors$BiFactor, ]
  heatmap_data_long <- melt(heatmap_data_top5, id.vars = "BiFactor", variable.name = "Indicator", value.name = "Value")
  
  color_palette <- c("#92d4e6", "#ceebf3", "#f0f6f6", "#f8e3d3", "#fcc7a9", "#f99c7c", "#fe7361", "#e22834", "#b5152c", "#840729")
  heatmap_plot <- ggplot(heatmap_data_long, aes(x = Indicator, y = BiFactor, fill = Value)) +
    geom_tile() +
    scale_fill_gradientn(colors = color_palette) +
    labs(title = paste(file_title, "Heatmap of Top 5 BiFactors"),
         x = "Indicator",
         y = "Bi-Factor") +
    theme_minimal()
  
  # Save plots
  ggsave(filename = paste0(file_title, "_standardized_values.png"), plot = group_bar_plot, width = 10, height = 6)
  ggsave(filename = paste0(file_title, "_top_5_bi_factors.png"), plot = sd_bar_plot, width = 10, height = 6)
  ggsave(filename = paste0(file_title, "_heatmap.png"), plot = heatmap_plot, width = 10, height = 6)
  
  return(invisible())
}

# Usage
# Provide the path to your CSV file
analyze_wheat_data("path/to/your/file.csv")
